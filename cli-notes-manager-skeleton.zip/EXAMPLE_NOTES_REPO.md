# Example Notes Repo

This repo includes `example_notes_repo/` only to let you test the app quickly.

To try it:
1. Copy config.example.toml to config.toml
2. Set:
   repo_path = "<path>/cli-notes-manager/example_notes_repo"
3. Run:
   notes-cli
