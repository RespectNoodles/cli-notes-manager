# Nmap

## Common
- `nmap -sV target`
